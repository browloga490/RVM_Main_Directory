#include "SharedLib.h"
int main()
{
        Signal_GenerationQuickSampleFinal();
        return 0;
}