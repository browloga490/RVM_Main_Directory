#include "SharedLib.h"
int main()
{
        Signal_GenerationQuickSample();
        return 0;
}